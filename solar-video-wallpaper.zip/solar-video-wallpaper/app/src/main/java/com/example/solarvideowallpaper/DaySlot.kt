package com.example.solarvideowallpaper

/**
 * Represents the four parts of the day supported by the wallpaper: morning,
 * day, evening and night. The boundaries between these periods can be
 * determined either by solar calculations (sunrise/sunset and twilight) or
 * by a fixed schedule defined by the user.
 */
enum class DaySlot {
    MORNING,
    DAY,
    EVENING,
    NIGHT
}