package com.example.solarvideowallpaper

import android.app.Application

/**
 * Application class that exposes the application context to [Preferences]
 * through [AppGlobals]. Using a global context is a simple way to avoid
 * passing context everywhere. For a production app, consider using
 * dependency injection (e.g. Hilt) instead.
 */
class MainApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGlobals.applicationContext = applicationContext
    }
}