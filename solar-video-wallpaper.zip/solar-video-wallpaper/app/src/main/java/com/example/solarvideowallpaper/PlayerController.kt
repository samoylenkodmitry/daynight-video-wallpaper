package com.example.solarvideowallpaper

import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

/**
 * Controls the [ExoPlayer] instance and swaps media items when the time slot changes.
 *
 * The controller maintains a mapping between [DaySlot] values and the selected
 * video URIs, which are persisted via [Preferences] (DataStore). When a new
 * slot is set, the corresponding URI is loaded and prepared for playback.
 */
class PlayerController {
    private var exoPlayer: ExoPlayer? = null
    private var currentSlot: DaySlot? = null

    /**
     * Attach the underlying [ExoPlayer] instance. Should be called once in the
     * service's `onCreate` callback.
     */
    fun attach(player: ExoPlayer) {
        this.exoPlayer = player
    }

    /**
     * Set the current day part. If the slot has changed, the controller
     * retrieves the corresponding URI from preferences and prepares it.
     */
    fun setSlot(slot: DaySlot) {
        if (slot == currentSlot) return
        currentSlot = slot
        val uri: Uri? = Preferences.slotUri(slot)
        if (uri != null) {
            val mediaItem = MediaItem.fromUri(uri)
            exoPlayer?.setMediaItem(mediaItem)
            exoPlayer?.prepare()
        }
    }

    /**
     * Ensure that playback is running for the given slot. If the slot
     * differs from the current one, the player will switch and start.
     */
    fun ensurePlayingFor(slot: DaySlot) {
        if (slot != currentSlot) {
            setSlot(slot)
        }
        if (exoPlayer?.isPlaying != true) {
            exoPlayer?.play()
        }
    }
}