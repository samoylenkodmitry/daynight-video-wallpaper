package com.example.solarvideowallpaper

import android.content.Context
import android.net.Uri
import androidx.datastore.preferences.core.Preferences as DataStorePreferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.preferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

/**
 * Utility object for persisting user preferences such as the selected video
 * URIs for each [DaySlot] and playback options like mute and loop. This
 * implementation uses Jetpack DataStore for type‑safe asynchronous storage.
 *
 * The URIs are stored as strings. When retrieving them, [Uri.parse] is used
 * to reconstruct the URI. If no URI has been saved for the given slot, the
 * methods return `null`.
 */
object Preferences {
    private const val DATA_STORE_NAME = "solar_video_wallpaper_prefs"
    private val Context.dataStore by preferencesDataStore(name = DATA_STORE_NAME)

    // Keys for each day slot
    private val MORNING_URI_KEY = stringPreferencesKey("morning_uri")
    private val DAY_URI_KEY = stringPreferencesKey("day_uri")
    private val EVENING_URI_KEY = stringPreferencesKey("evening_uri")
    private val NIGHT_URI_KEY = stringPreferencesKey("night_uri")

    /**
     * Retrieve the persisted URI for the given slot. Returns `null` if none
     * exists. This method blocks the current thread for simplicity; callers
     * should consider using coroutines for a non‑blocking alternative.
     */
    fun slotUri(slot: DaySlot): Uri? {
        // In a real implementation the context should not be null. Here we
        // assume a globally accessible application context exists.
        val context = AppGlobals.applicationContext ?: return null
        val key = when (slot) {
            DaySlot.MORNING -> MORNING_URI_KEY
            DaySlot.DAY -> DAY_URI_KEY
            DaySlot.EVENING -> EVENING_URI_KEY
            DaySlot.NIGHT -> NIGHT_URI_KEY
        }
        val value = runBlocking {
            val prefs = context.dataStore.data.first()
            prefs[key]
        }
        return value?.let { Uri.parse(it) }
    }

    /**
     * Persist a URI for the given slot. Replaces any previously saved value.
     */
    suspend fun setSlotUri(context: Context, slot: DaySlot, uri: Uri) {
        val key = when (slot) {
            DaySlot.MORNING -> MORNING_URI_KEY
            DaySlot.DAY -> DAY_URI_KEY
            DaySlot.EVENING -> EVENING_URI_KEY
            DaySlot.NIGHT -> NIGHT_URI_KEY
        }
        context.dataStore.edit { prefs ->
            prefs[key] = uri.toString()
        }
    }
}

/**
 * A placeholder singleton used to expose the application context to static
 * preference methods. In a real application you might use dependency
 * injection or pass the context explicitly instead of relying on a global.
 */
object AppGlobals {
    var applicationContext: Context? = null
}