package com.example.solarvideowallpaper

import android.content.Context
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

/**
 * Live wallpaper service that plays a user‑selected video on the home/lock screen.
 *
 * This implementation delegates playback details to [PlayerController] and uses
 * [TimeSchemeController] to decide which video to play based on the current
 * time of day. The core pattern of creating an `Engine` and attaching an
 * `ExoPlayer` instance to a `Surface` is adapted from Android's official
 * documentation and sample code for live wallpapers. See the discussion
 * around `WallpaperService.Engine` and video surfaces in the Jetpack
 * documentation for details【296525096667110†L24-L33】.
 */
class SolarVideoWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = VideoEngine()

    private inner class VideoEngine : Engine(), Player.Listener {
        private var exoPlayer: ExoPlayer? = null
        private val playerController: PlayerController = PlayerController()
        private lateinit var timeSchemeController: TimeSchemeController
        private var visible: Boolean = false

        override fun onCreate(surfaceHolder: SurfaceHolder) {
            super.onCreate(surfaceHolder)
            // Initialize ExoPlayer. Use the application context to avoid leaking the service.
            exoPlayer = ExoPlayer.Builder(this@SolarVideoWallpaperService).build().apply {
                // Repeat the video indefinitely.
                repeatMode = Player.REPEAT_MODE_ALL
                // Start muted; user can toggle audio in settings.
                volume = 0f
                addListener(this@VideoEngine)
                // Attach to controller.
                playerController.attach(this)
            }
            // Initialize time scheme controller to listen for day part changes.
            timeSchemeController = TimeSchemeController(applicationContext) { slot ->
                // When the slot changes, tell the player controller to swap videos.
                playerController.setSlot(slot)
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            super.onSurfaceCreated(holder)
            exoPlayer?.setVideoSurface(holder.surface)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            super.onSurfaceDestroyed(holder)
            exoPlayer?.clearVideoSurface()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            this.visible = visible
            if (visible) {
                // Ensure the correct video is selected and start playback.
                val currentSlot = timeSchemeController.currentSlot()
                playerController.ensurePlayingFor(currentSlot)
                exoPlayer?.play()
            } else {
                exoPlayer?.pause()
            }
        }

        override fun onDestroy() {
            // Clean up resources when the engine is destroyed.
            exoPlayer?.release()
            exoPlayer = null
            timeSchemeController.dispose()
            super.onDestroy()
        }
    }
}