package com.example.solarvideowallpaper

import android.content.Context
import android.location.Location
import ca.rmen.sunrisesunset.SunriseSunset
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Computes the current [DaySlot] based on either solar calculations or a fixed
 * schedule defined by the user. When a new slot is computed, the provided
 * callback is invoked so the wallpaper can update its video. The solar
 * calculations rely on the open‑source **SunriseSunset** library【185012492945770†L3-L13】 to obtain
 * sunrise, sunset and twilight times without network access【185012492945770†L3-L13】.
 *
 * This class abstracts away coroutines and location updates. By default it
 * ticks once per minute. Users who wish to update more or less frequently
 * can modify the `ticker` implementation.
 */
class TimeSchemeController(
    private val context: Context,
    private val onSlotChange: (DaySlot) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var lastSlot: DaySlot? = null

    init {
        scope.launch {
            // Combine flows for current time and location. When either changes,
            // recompute the current slot.
            combine(timeTicker(), locationFlow()) { now, loc ->
                computeSlot(now, loc)
            }
                .distinctUntilChanged()
                .onEach { slot ->
                    lastSlot = slot
                    onSlotChange(slot)
                }
                .collect { }
        }
    }

    /**
     * Returns the most recently computed slot. If none has been computed yet,
     * defaults to [DaySlot.DAY].
     */
    fun currentSlot(): DaySlot = lastSlot ?: DaySlot.DAY

    /**
     * Cancel the internal coroutine scope when no longer needed.
     */
    fun dispose() {
        scope.cancel()
    }

    /**
     * Flow that emits the current time in milliseconds every minute. Adjust
     * the tick frequency here if necessary.
     */
    private fun timeTicker(): Flow<Long> = flow {
        while (true) {
            emit(System.currentTimeMillis())
            kotlinx.coroutines.delay(60_000L)
        }
    }

    /**
     * Flow that emits the last known location. This implementation always
     * emits `null`; a real implementation should hook into the Android
     * location APIs and emit updates when they change. When null is
     * provided, solar calculations fall back to a fixed schedule.
     */
    private fun locationFlow(): Flow<Location?> = flow {
        emit(null)
    }

    /**
     * Determines which [DaySlot] applies at the given time and location. If
     * `location` is null, a fixed schedule is used: morning 6–12, day 12–18,
     * evening 18–21 and night otherwise. If a location is available, the
     * [SunriseSunset] library is used to compute sunrise, sunset and civil
     * twilight times【185012492945770†L3-L13】. Morning runs from civil dawn to sunrise, day from
     * sunrise to sunset, evening from sunset to civil dusk, and night
     * otherwise.
     */
    private fun computeSlot(nowMillis: Long, location: Location?): DaySlot {
        val calendar = Calendar.getInstance().apply { timeInMillis = nowMillis }
        if (location != null) {
            return try {
                val lat = location.latitude
                val lon = location.longitude
                // Sunrise and sunset.
                val sunriseSunset = SunriseSunset.getSunriseSunset(calendar, lat, lon)
                val sunrise = sunriseSunset[0].timeInMillis
                val sunset = sunriseSunset[1].timeInMillis
                // Civil twilight: returns [dawn, dusk]
                val civil = SunriseSunset.getCivilTwilight(calendar, lat, lon)
                val civilDawn = civil[0].timeInMillis
                val civilDusk = civil[1].timeInMillis
                return when (nowMillis) {
                    in civilDawn until sunrise -> DaySlot.MORNING
                    in sunrise until sunset -> DaySlot.DAY
                    in sunset until civilDusk -> DaySlot.EVENING
                    else -> DaySlot.NIGHT
                }
            } catch (e: Exception) {
                // In case of any error, fall back to fixed schedule.
                computeFixedSchedule(calendar)
            }
        }
        // Without location use fixed schedule.
        return computeFixedSchedule(calendar)
    }

    /**
     * Fallback schedule used when no location is available or solar
     * calculations fail. Morning is 6–12, day 12–18, evening 18–21, night
     * otherwise. Times are local to the device.
     */
    private fun computeFixedSchedule(calendar: Calendar): DaySlot {
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        return when (hour) {
            in 6 until 12 -> DaySlot.MORNING
            in 12 until 18 -> DaySlot.DAY
            in 18 until 21 -> DaySlot.EVENING
            else -> DaySlot.NIGHT
        }
    }
}