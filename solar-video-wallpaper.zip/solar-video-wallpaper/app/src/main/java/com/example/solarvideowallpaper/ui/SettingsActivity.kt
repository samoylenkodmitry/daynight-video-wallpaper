package com.example.solarvideowallpaper.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import com.example.solarvideowallpaper.ui.screens.SettingsScreen

/**
 * Activity that hosts the Compose UI for configuring the live wallpaper. Users
 * can select different videos for each [DaySlot], toggle mute and loop
 * settings, and choose between solar‑aware and fixed schedules.
 */
class SettingsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    SettingsScreen()
                }
            }
        }
    }
}