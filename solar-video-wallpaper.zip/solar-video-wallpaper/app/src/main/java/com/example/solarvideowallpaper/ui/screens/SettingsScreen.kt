package com.example.solarvideowallpaper.ui.screens

import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import com.example.solarvideowallpaper.DaySlot
import com.example.solarvideowallpaper.Preferences

/**
 * Settings screen for configuring the live wallpaper. This Compose UI allows
 * users to select video files for each time of day and toggle playback
 * behaviour. For brevity the implementation here is minimal; in a full
 * application you would handle permission requests, persist selections via
 * [Preferences], and expose time pickers for fixed schedules.
 */
@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val selectedMode = remember { mutableStateOf(Mode.SOLAR) }
    val muteEnabled = remember { mutableStateOf(true) }
    val loopEnabled = remember { mutableStateOf(true) }

    // Launchers for picking videos. Each result callback stores the URI in preferences.
    val pickVideoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            // Save the URI for the currently selected slot. In a real
            // implementation you would know which button triggered the picker.
            // Here we simply save it for the MORNING slot as a placeholder.
            // Persist the permission to read this URI across reboots by taking
            // persistable URI permission.
            try {
                // context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
                // ignore
            }
            // Save the URI in preferences. Because setSlotUri is suspend, we
            // would normally launch a coroutine. Omitted for brevity.
        }
    }

    Column {
        Text(text = "Configure Videos")
        Spacer(modifier = Modifier.height(8.dp))
        // Buttons for picking each video. In a real implementation you would
        // create one for each DaySlot and pass the slot to the preferences.
        Button(onClick = { pickVideoLauncher.launch(arrayOf("video/*")) }) {
            Text("Pick Morning Video")
        }
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = { /* pick day video */ }) {
            Text("Pick Day Video")
        }
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = { /* pick evening video */ }) {
            Text("Pick Evening Video")
        }
        Spacer(modifier = Modifier.height(4.dp))
        Button(onClick = { /* pick night video */ }) {
            Text("Pick Night Video")
        }
        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Playback Settings")
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            Text("Mute audio")
            Switch(checked = muteEnabled.value, onCheckedChange = { muteEnabled.value = it })
        }
        Row {
            Text("Loop video")
            Switch(checked = loopEnabled.value, onCheckedChange = { loopEnabled.value = it })
        }
        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Mode")
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            RadioButton(
                selected = selectedMode.value == Mode.SOLAR,
                onClick = { selectedMode.value = Mode.SOLAR }
            )
            Text("Solar Mode")
        }
        Row {
            RadioButton(
                selected = selectedMode.value == Mode.FIXED,
                onClick = { selectedMode.value = Mode.FIXED }
            )
            Text("Fixed Schedule")
        }
        // TODO: show time pickers when fixed schedule is selected
    }
}

/**
 * Modes available for determining the current day part.
 */
private enum class Mode {
    SOLAR,
    FIXED
}